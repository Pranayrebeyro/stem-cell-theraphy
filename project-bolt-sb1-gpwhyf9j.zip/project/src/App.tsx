import React, { useState } from 'react';
import { Moon, Sun, Search, User, Calendar, Activity, Clock, Bell, Home, BookOpen, FileText, Users, Menu, X } from 'lucide-react';
import PatientDashboard from './components/PatientDashboard';
import Blog from './components/Blog';
import SuccessStories from './components/SuccessStories';
import HomePage from './components/HomePage';

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [currentPage, setCurrentPage] = useState('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [patientData, setPatientData] = useState(null);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // In a real app, this would be an API call
      // Mock patient data for demonstration
      setPatientData({
        name: searchQuery,
        id: 'PT-' + Math.floor(Math.random() * 10000),
        surgeryDate: '2023-10-15',
        surgeryType: 'Autologous Stem Cell Transplantation',
        healingProgress: 68,
        currentStage: 'Tissue Regeneration',
        estimatedRecovery: '2024-01-20',
        nextConsultation: '2023-12-05',
        recommendations: [
          'Maintain a protein-rich diet',
          'Light walking exercise (15 minutes daily)',
          'Avoid strenuous activities for 2 more weeks',
          'Continue prescribed medications'
        ],
        alerts: [
          'Slight inflammation detected - monitor closely',
          'Schedule follow-up blood work'
        ]
      });
      setCurrentPage('dashboard');
    }
  };

  return (
    <div className={`min-h-screen flex flex-col ${darkMode ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'}`}>
      {/* Header */}
      <header className={`sticky top-0 z-50 ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Activity className="h-8 w-8 text-blue-600" />
            <span className="text-xl font-bold">JPR Hospital</span>
          </div>
          
          <div className="hidden md:flex items-center space-x-6">
            <button 
              onClick={() => setCurrentPage('home')}
              className={`font-medium ${currentPage === 'home' ? 'text-blue-600' : ''}`}
            >
              Home
            </button>
            <button 
              onClick={() => setCurrentPage('dashboard')}
              className={`font-medium ${currentPage === 'dashboard' ? 'text-blue-600' : ''}`}
            >
              Patient Dashboard
            </button>
            <button 
              onClick={() => setCurrentPage('blog')}
              className={`font-medium ${currentPage === 'blog' ? 'text-blue-600' : ''}`}
            >
              Blog
            </button>
            <button 
              onClick={() => setCurrentPage('success')}
              className={`font-medium ${currentPage === 'success' ? 'text-blue-600' : ''}`}
            >
              Success Stories
            </button>
          </div>
          
          <div className="flex items-center space-x-4">
            <button 
              onClick={toggleDarkMode}
              className={`p-2 rounded-full ${darkMode ? 'bg-gray-700' : 'bg-gray-200'}`}
              aria-label="Toggle dark mode"
            >
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
            
            <button 
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className={`md:hidden ${darkMode ? 'bg-gray-800' : 'bg-white'} py-4 px-4`}>
            <div className="flex flex-col space-y-3">
              <button 
                onClick={() => {
                  setCurrentPage('home');
                  setMobileMenuOpen(false);
                }}
                className={`font-medium ${currentPage === 'home' ? 'text-blue-600' : ''} py-2`}
              >
                <div className="flex items-center space-x-2">
                  <Home className="h-5 w-5" />
                  <span>Home</span>
                </div>
              </button>
              <button 
                onClick={() => {
                  setCurrentPage('dashboard');
                  setMobileMenuOpen(false);
                }}
                className={`font-medium ${currentPage === 'dashboard' ? 'text-blue-600' : ''} py-2`}
              >
                <div className="flex items-center space-x-2">
                  <Activity className="h-5 w-5" />
                  <span>Patient Dashboard</span>
                </div>
              </button>
              <button 
                onClick={() => {
                  setCurrentPage('blog');
                  setMobileMenuOpen(false);
                }}
                className={`font-medium ${currentPage === 'blog' ? 'text-blue-600' : ''} py-2`}
              >
                <div className="flex items-center space-x-2">
                  <BookOpen className="h-5 w-5" />
                  <span>Blog</span>
                </div>
              </button>
              <button 
                onClick={() => {
                  setCurrentPage('success');
                  setMobileMenuOpen(false);
                }}
                className={`font-medium ${currentPage === 'success' ? 'text-blue-600' : ''} py-2`}
              >
                <div className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>Success Stories</span>
                </div>
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Search bar - visible on dashboard page */}
      {currentPage === 'dashboard' && (
        <div className={`py-4 ${darkMode ? 'bg-gray-800' : 'bg-blue-50'}`}>
          <div className="container mx-auto px-4">
            <form onSubmit={handleSearch} className="flex items-center">
              <div className="relative flex-grow">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search patient by name..."
                  className={`pl-10 pr-4 py-2 w-full rounded-l-lg border ${
                    darkMode 
                      ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' 
                      : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                  }`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-r-lg"
              >
                Search
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Main content */}
      <main className="flex-grow">
        {currentPage === 'home' && <HomePage darkMode={darkMode} setCurrentPage={setCurrentPage} />}
        {currentPage === 'dashboard' && <PatientDashboard darkMode={darkMode} patientData={patientData} />}
        {currentPage === 'blog' && <Blog darkMode={darkMode} />}
        {currentPage === 'success' && <SuccessStories darkMode={darkMode} />}
      </main>

      {/* Footer */}
      <footer className={`py-6 ${darkMode ? 'bg-gray-800' : 'bg-gray-100'}`}>
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Activity className="h-6 w-6 text-blue-600" />
              <span className="font-bold">JPR Hospital</span>
            </div>
            <div className="text-sm text-center md:text-right">
              <p>&copy; {new Date().getFullYear()} JPR Hospital. All rights reserved.</p>
              <p className="mt-1">AI-Powered Stem Cell Recovery Tracking</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;