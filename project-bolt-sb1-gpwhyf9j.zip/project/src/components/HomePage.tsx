import React from 'react';
import { ArrowRight, Brain, Activity, Calendar, Shield } from 'lucide-react';

interface HomePageProps {
  darkMode: boolean;
  setCurrentPage: (page: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ darkMode, setCurrentPage }) => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-800 opacity-90"></div>
        <div 
          className="relative h-[500px] bg-cover bg-center flex items-center"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1581093588401-fbb62a02f120?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')" }}
        >
          <div className="container mx-auto px-4">
            <div className="max-w-2xl">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                AI-Driven Recovery for a Healthier Tomorrow!
              </h1>
              <p className="text-xl text-white mb-8">
                JPR Hospital combines cutting-edge AI technology with advanced stem cell therapy to 
                revolutionize patient recovery and healing.
              </p>
              <button 
                onClick={() => setCurrentPage('dashboard')}
                className="bg-white text-blue-600 hover:bg-blue-50 px-6 py-3 rounded-lg font-medium flex items-center"
              >
                Track Recovery
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className={`py-16 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How Our AI-Powered System Works</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className={`p-6 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-blue-50'} flex flex-col items-center text-center`}>
              <div className="bg-blue-600 p-3 rounded-full mb-4">
                <Activity className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Precise Recovery Tracking</h3>
              <p>
                Our AI algorithms analyze patient data to provide accurate healing progress and 
                personalized recovery timelines.
              </p>
            </div>
            
            <div className={`p-6 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-blue-50'} flex flex-col items-center text-center`}>
              <div className="bg-blue-600 p-3 rounded-full mb-4">
                <Brain className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Intelligent Healing Insights</h3>
              <p>
                Get AI-powered recommendations for diet, exercise, and post-surgery care 
                tailored to your specific recovery needs.
              </p>
            </div>
            
            <div className={`p-6 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-blue-50'} flex flex-col items-center text-center`}>
              <div className="bg-blue-600 p-3 rounded-full mb-4">
                <Calendar className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Smart Consultation Reminders</h3>
              <p>
                Our system automatically schedules follow-up appointments and sends alerts 
                if complications are detected.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About Stem Cell Therapy */}
      <section className={`py-16 ${darkMode ? 'bg-gray-800' : 'bg-gray-100'}`}>
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0 md:pr-8">
              <img 
                src="https://images.unsplash.com/photo-1579154204601-01588f351e67?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
                alt="Stem Cell Research" 
                className="rounded-lg shadow-lg"
              />
            </div>
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-6">Pioneering Stem Cell Therapy</h2>
              <p className="mb-4">
                At JPR Hospital, we're at the forefront of stem cell research and therapy. Our 
                innovative treatments harness the body's natural healing abilities to accelerate 
                recovery and improve patient outcomes.
              </p>
              <p className="mb-6">
                Our AI-powered tracking system monitors tissue regeneration, predicts healing 
                milestones, and provides personalized care recommendations throughout your 
                recovery journey.
              </p>
              <button 
                onClick={() => setCurrentPage('blog')}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium flex items-center"
              >
                Learn More
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className={`py-16 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Patient Success Stories</h2>
          
          <div className={`p-8 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-blue-50'} mb-8`}>
            <div className="flex items-start">
              <img 
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80" 
                alt="Patient" 
                className="w-16 h-16 rounded-full object-cover mr-4"
              />
              <div>
                <h3 className="text-xl font-semibold">Sarah Johnson</h3>
                <p className="text-sm mb-4">Knee Cartilage Regeneration</p>
                <p className="italic">
                  "The AI-powered recovery tracking at JPR Hospital transformed my healing journey. 
                  I could see my progress day by day, and the personalized recommendations helped me 
                  recover faster than expected. Six months post-surgery, I'm back to my active lifestyle!"
                </p>
              </div>
            </div>
          </div>
          
          <div className="text-center">
            <button 
              onClick={() => setCurrentPage('success')}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium inline-flex items-center"
            >
              View All Success Stories
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-800 py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Experience the Future of Recovery Tracking
          </h2>
          <p className="text-xl text-white mb-8 max-w-3xl mx-auto">
            Join thousands of patients who have benefited from our AI-powered stem cell 
            recovery tracking system at JPR Hospital.
          </p>
          <button 
            onClick={() => setCurrentPage('dashboard')}
            className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-4 rounded-lg font-medium text-lg inline-flex items-center"
          >
            Start Tracking Your Recovery
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </section>
    </div>
  );
};

export default HomePage;