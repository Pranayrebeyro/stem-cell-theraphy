import React from 'react';
import { Calendar, User, ArrowRight, BookOpen, ThumbsUp, MessageSquare } from 'lucide-react';

interface BlogProps {
  darkMode: boolean;
}

const Blog: React.FC<BlogProps> = ({ darkMode }) => {
  const blogPosts = [
    {
      id: 1,
      title: "Breakthrough in Stem Cell Therapy for Cartilage Regeneration",
      excerpt: "New research at JPR Hospital shows promising results in using AI-guided stem cell therapy for knee cartilage regeneration, with 87% of patients showing significant improvement.",
      author: "Dr. Emily Chen",
      date: "November 15, 2023",
      image: "https://images.unsplash.com/photo-1576671414121-aa2d0967818d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      category: "Research",
      likes: 124,
      comments: 32
    },
    {
      id: 2,
      title: "How AI is Revolutionizing Post-Surgery Recovery Tracking",
      excerpt: "JPR Hospital's AI-powered recovery tracking system is changing how patients and doctors monitor healing progress, leading to faster recovery times and better outcomes.",
      author: "Dr. Michael Rodriguez",
      date: "October 28, 2023",
      image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      category: "Technology",
      likes: 98,
      comments: 17
    },
    {
      id: 3,
      title: "Nutritional Guidelines for Optimal Stem Cell Recovery",
      excerpt: "Our nutrition experts share evidence-based dietary recommendations to support stem cell therapy recovery, including key nutrients that promote tissue regeneration.",
      author: "Sarah Johnson, RD",
      date: "October 12, 2023",
      image: "https://images.unsplash.com/photo-1498837167922-ddd27525d352?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      category: "Nutrition",
      likes: 76,
      comments: 23
    },
    {
      id: 4,
      title: "The Future of Regenerative Medicine: JPR Hospital's Research Pipeline",
      excerpt: "Explore our cutting-edge research initiatives in stem cell therapy and AI-driven personalized medicine that are set to transform patient care in the coming years.",
      author: "Dr. James Wilson",
      date: "September 30, 2023",
      image: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
      category: "Research",
      likes: 112,
      comments: 28
    }
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Blog Header */}
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Latest Insights & Research</h1>
        <p className="max-w-2xl mx-auto">
          Stay updated with the latest breakthroughs in stem cell therapy, 
          AI-powered recovery tracking, and regenerative medicine from JPR Hospital.
        </p>
      </div>

      {/* Featured Article */}
      <div className={`rounded-lg overflow-hidden shadow-lg mb-12 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="relative">
          <img 
            src="https://images.unsplash.com/photo-1530026186672-2cd00ffc50fe?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
            alt="AI in Stem Cell Research" 
            className="w-full h-[400px] object-cover"
          />
          <div className="absolute top-4 left-4 bg-blue-600 text-white px-4 py-1 rounded-full">
            Featured
          </div>
        </div>
        <div className="p-6">
          <div className="flex items-center mb-4">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${darkMode ? 'bg-blue-900 text-blue-200' : 'bg-blue-100 text-blue-800'}`}>
              Research Spotlight
            </span>
            <div className="flex items-center ml-4 text-sm">
              <Calendar className="h-4 w-4 mr-1" />
              <span>December 1, 2023</span>
            </div>
          </div>
          <h2 className="text-2xl font-bold mb-3">
            JPR Hospital's AI Algorithm Predicts Stem Cell Therapy Outcomes with 94% Accuracy
          </h2>
          <p className="mb-4">
            A groundbreaking study from JPR Hospital reveals how our proprietary AI algorithm 
            can predict patient outcomes from stem cell therapy with unprecedented accuracy, 
            allowing for truly personalized treatment plans and recovery tracking.
          </p>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <img 
                src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80" 
                alt="Dr. Robert Kim" 
                className="w-10 h-10 rounded-full object-cover mr-3"
              />
              <span>Dr. Robert Kim, Research Director</span>
            </div>
            <button className="text-blue-600 font-medium flex items-center">
              Read Full Article
              <ArrowRight className="ml-1 h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Blog Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {blogPosts.map((post) => (
          <div 
            key={post.id} 
            className={`rounded-lg overflow-hidden shadow-md ${darkMode ? 'bg-gray-800' : 'bg-white'}`}
          >
            <img 
              src={post.image} 
              alt={post.title} 
              className="w-full h-48 object-cover"
            />
            <div className="p-5">
              <div className="flex items-center mb-3">
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${darkMode ? 'bg-blue-900 text-blue-200' : 'bg-blue-100 text-blue-800'}`}>
                  {post.category}
                </span>
                <div className="flex items-center ml-3 text-xs">
                  <Calendar className="h-3 w-3 mr-1" />
                  <span>{post.date}</span>
                </div>
              </div>
              <h3 className="font-bold text-lg mb-2">{post.title}</h3>
              <p className={`text-sm mb-4 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {post.excerpt}
              </p>
              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm">
                  <User className="h-4 w-4 mr-1" />
                  <span>{post.author}</span>
                </div>
                <div className="flex items-center space-x-3 text-sm">
                  <div className="flex items-center">
                    <ThumbsUp className="h-4 w-4 mr-1" />
                    <span>{post.likes}</span>
                  </div>
                  <div className="flex items-center">
                    <MessageSquare className="h-4 w-4 mr-1" />
                    <span>{post.comments}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Educational Resources */}
      <div className={`mt-16 p-8 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-blue-50'}`}>
        <h2 className="text-2xl font-bold mb-6 flex items-center">
          <BookOpen className="h-6 w-6 mr-2 text-blue-600" />
          Educational Resources
        </h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className={`p-5 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-white'} shadow-md`}>
            <h3 className="font-bold mb-2">Understanding Stem Cell Therapy</h3>
            <p className="text-sm mb-3">
              A comprehensive guide to how stem cell therapy works and its applications 
              in various medical conditions.
            </p>
            <button className="text-blue-600 text-sm font-medium flex items-center">
              Download PDF
              <ArrowRight className="ml-1 h-4 w-4" />
            </button>
          </div>
          
          <div className={`p-5 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-white'} shadow-md`}>
            <h3 className="font-bold mb-2">Recovery Timeline Expectations</h3>
            <p className="text-sm mb-3">
              What to expect during your recovery journey after stem cell therapy, 
              with week-by-week milestones.
            </p>
            <button className="text-blue-600 text-sm font-medium flex items-center">
              Download PDF
              <ArrowRight className="ml-1 h-4 w-4" />
            </button>
          </div>
          
          <div className={`p-5 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-white'} shadow-md`}>
            <h3 className="font-bold mb-2">Nutrition & Exercise Guidelines</h3>
            <p className="text-sm mb-3">
              Expert recommendations for diet and physical activity to optimize 
              your stem cell therapy results.
            </p>
            <button className="text-blue-600 text-sm font-medium flex items-center">
              Download PDF
              <ArrowRight className="ml-1 h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Newsletter Signup */}
      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Stay Updated with Our Research</h2>
        <p className="max-w-2xl mx-auto mb-6">
          Subscribe to our newsletter to receive the latest updates on stem cell research, 
          AI advancements, and patient success stories.
        </p>
        <div className="max-w-md mx-auto">
          <div className="flex">
            <input 
              type="email" 
              placeholder="Your email address" 
              className={`flex-grow px-4 py-2 rounded-l-lg border ${
                darkMode 
                  ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' 
                  : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
              }`}
            />
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-r-lg">
              Subscribe
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog;