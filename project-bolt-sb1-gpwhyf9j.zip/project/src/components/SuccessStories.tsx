import React from 'react';
import { User, Calendar, Star, Quote, ArrowRight } from 'lucide-react';

interface SuccessStoriesProps {
  darkMode: boolean;
}

const SuccessStories: React.FC<SuccessStoriesProps> = ({ darkMode }) => {
  const successStories = [
    {
      id: 1,
      name: "David Thompson",
      age: 42,
      condition: "Knee Cartilage Damage",
      treatment: "Autologous Stem Cell Therapy",
      recoveryTime: "4 months",
      story: "After years of knee pain and limited mobility from sports injuries, I was considering knee replacement surgery. The stem cell therapy at JPR Hospital changed everything. The AI tracking system kept me motivated by showing my progress, and now I'm back to hiking and playing tennis with my kids.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
      date: "October 2023",
      rating: 5
    },
    {
      id: 2,
      name: "Maria Rodriguez",
      age: 56,
      condition: "Degenerative Disc Disease",
      treatment: "Mesenchymal Stem Cell Injection",
      recoveryTime: "6 months",
      story: "I lived with chronic back pain for over a decade. Multiple surgeries and treatments provided only temporary relief. The stem cell therapy at JPR Hospital was different. The AI recovery tracking helped me understand my healing process, and for the first time in years, I can enjoy gardening and playing with my grandchildren without pain.",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
      date: "August 2023",
      rating: 5
    },
    {
      id: 3,
      name: "James Wilson",
      age: 38,
      condition: "Rotator Cuff Tear",
      treatment: "Adipose-Derived Stem Cell Therapy",
      recoveryTime: "3 months",
      story: "As a construction worker, my shoulder injury threatened my career. Traditional treatments weren't working, and surgery had a long recovery time. The stem cell therapy at JPR Hospital was minimally invasive, and the AI recovery tracking gave me clear milestones. I returned to work faster than expected and with full strength in my shoulder.",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
      date: "September 2023",
      rating: 5
    },
    {
      id: 4,
      name: "Emily Chen",
      age: 29,
      condition: "Autoimmune Arthritis",
      treatment: "Allogeneic Stem Cell Therapy",
      recoveryTime: "5 months",
      story: "I was diagnosed with autoimmune arthritis in my early 20s, and it progressively worsened despite medications. The stem cell therapy at JPR Hospital has significantly reduced my inflammation and pain. The AI recovery tracking helped me understand what to expect at each stage, and now I'm back to dancing and enjoying an active lifestyle.",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
      date: "July 2023",
      rating: 4
    }
  ];

  const renderStars = (rating: number) => {
    return Array(5).fill(0).map((_, i) => (
      <Star 
        key={i} 
        className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
      />
    ));
  };

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Patient Success Stories</h1>
        <p className="max-w-2xl mx-auto">
          Real stories from real patients who have experienced remarkable recoveries 
          through JPR Hospital's AI-powered stem cell therapy program.
        </p>
      </div>

      {/* Featured Success Story */}
      <div className={`rounded-lg overflow-hidden shadow-lg mb-16 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="md:flex">
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
              alt="Robert Johnson Recovery" 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="md:w-1/2 p-8">
            <div className="flex items-center mb-4">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${darkMode ? 'bg-green-900 text-green-200' : 'bg-green-100 text-green-800'}`}>
                Featured Story
              </span>
              <div className="flex items-center ml-4 text-sm">
                <Calendar className="h-4 w-4 mr-1" />
                <span>November 2023</span>
              </div>
            </div>
            
            <h2 className="text-2xl font-bold mb-4">Robert Johnson's Journey: From Wheelchair to Marathon</h2>
            
            <div className="flex items-center mb-6">
              <img 
                src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80" 
                alt="Robert Johnson" 
                className="w-16 h-16 rounded-full object-cover mr-4"
              />
              <div>
                <p className="font-semibold">Robert Johnson, 45</p>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Spinal Cord Injury | Stem Cell Regenerative Therapy
                </p>
              </div>
            </div>
            
            <div className="mb-6">
              <Quote className="h-8 w-8 text-blue-600 mb-2" />
              <p className="italic">
                "After my accident, doctors told me I might never walk again. The stem cell therapy 
                at JPR Hospital and their AI-powered recovery tracking gave me hope and a clear path 
                forward. Today, not only can I walk, but I've completed my first half-marathon. 
                The personalized recovery insights helped me push through the toughest days."
              </p>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex">
                {renderStars(5)}
              </div>
              <button className="text-blue-600 font-medium flex items-center">
                Read Full Story
                <ArrowRight className="ml-1 h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Success Stories Grid */}
      <div className="grid md:grid-cols-2 gap-8">
        {successStories.map((story) => (
          <div 
            key={story.id} 
            className={`rounded-lg overflow-hidden shadow-md ${darkMode ? 'bg-gray-800' : 'bg-white'}`}
          >
            <div className="p-6">
              <div className="flex items-start">
                <img 
                  src={story.image} 
                  alt={story.name} 
                  className="w-20 h-20 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="font-bold text-lg">{story.name}, {story.age}</h3>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {story.condition} | {story.treatment}
                  </p>
                  <div className="flex items-center mt-1 mb-3">
                    <span className={`text-xs px-2 py-1 rounded-full ${darkMode ? 'bg-blue-900 text-blue-200' : 'bg-blue-100 text-blue-800'}`}>
                      Recovery: {story.recoveryTime}
                    </span>
                    <div className="flex ml-3">
                      {renderStars(story.rating)}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-4">
                <Quote className="h-6 w-6 text-blue-600 mb-2" />
                <p className="italic text-sm">
                  "{story.story}"
                </p>
              </div>
              
              <div className="mt-4 flex justify-between items-center">
                <span className="text-xs flex items-center">
                  <Calendar className="h-3 w-3 mr-1" />
                  {story.date}
                </span>
                <button className="text-blue-600 text-sm font-medium flex items-center">
                  Read More
                  <ArrowRight className="ml-1 h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recovery Statistics */}
      <div className={`mt-16 p-8 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-blue-50'}`}>
        <h2 className="text-2xl font-bold mb-8 text-center">Our Recovery Success Rates</h2>
        
        <div className="grid md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4 ${darkMode ? 'bg-blue-900' : 'bg-blue-100'}`}>
              <span className="text-3xl font-bold text-blue-600">92%</span>
            </div>
            <p className="font-medium">Patients Reporting Significant Pain Reduction</p>
          </div>
          
          <div className="text-center">
            <div className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4 ${darkMode ? 'bg-blue-900' : 'bg-blue-100'}`}>
              <span className="text-3xl font-bold text-blue-600">87%</span>
            </div>
            <p className="font-medium">Improved Mobility & Function</p>
          </div>
          
          <div className="text-center">
            <div className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4 ${darkMode ? 'bg-blue-900' : 'bg-blue-100'}`}>
              <span className="text-3xl font-bold text-blue-600">78%</span>
            </div>
            <p className="font-medium">Faster Than Expected Recovery</p>
          </div>
          
          <div className="text-center">
            <div className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4 ${darkMode ? 'bg-blue-900' : 'bg-blue-100'}`}>
              <span className="text-3xl font-bold text-blue-600">94%</span>
            </div>
            <p className="font-medium">Patient Satisfaction Rate</p>
          </div>
        </div>
      </div>

      {/* Share Your Story */}
      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Share Your Recovery Journey</h2>
        <p className="max-w-2xl mx-auto mb-6">
          Have you experienced success with JPR Hospital's stem cell therapy? 
          We'd love to hear your story and share it with others seeking hope and healing.
        </p>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium inline-flex items-center">
          Submit Your Story
          <ArrowRight className="ml-2 h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default SuccessStories;