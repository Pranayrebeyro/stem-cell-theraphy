import React from 'react';
import { User, Calendar, Activity, Clock, Bell, ArrowRight, CheckCircle, AlertCircle } from 'lucide-react';

interface PatientData {
  name: string;
  id: string;
  surgeryDate: string;
  surgeryType: string;
  healingProgress: number;
  currentStage: string;
  estimatedRecovery: string;
  nextConsultation: string;
  recommendations: string[];
  alerts: string[];
}

interface PatientDashboardProps {
  darkMode: boolean;
  patientData: PatientData | null;
}

const PatientDashboard: React.FC<PatientDashboardProps> = ({ darkMode, patientData }) => {
  // Format date from YYYY-MM-DD to Month DD, YYYY
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  // Calculate days remaining until full recovery
  const calculateDaysRemaining = (dateString: string) => {
    const today = new Date();
    const recoveryDate = new Date(dateString);
    const diffTime = recoveryDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  if (!patientData) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className={`p-8 rounded-lg shadow-md text-center ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
          <Activity className="h-16 w-16 text-blue-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-4">Patient Recovery Dashboard</h2>
          <p className="mb-6">
            Search for a patient by name to view their stem cell recovery progress, 
            healing insights, and personalized recommendations.
          </p>
          <div className="flex justify-center">
            <div className={`p-4 rounded-lg max-w-md ${darkMode ? 'bg-gray-700' : 'bg-blue-50'}`}>
              <p className="text-sm">
                <strong>Note:</strong> This dashboard provides AI-powered insights based on patient data, 
                treatment history, and recovery patterns to help optimize the healing process.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const daysRemaining = calculateDaysRemaining(patientData.estimatedRecovery);

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Patient Info Header */}
      <div className={`p-6 rounded-lg shadow-md mb-8 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="bg-blue-100 p-3 rounded-full mr-4">
              <User className="h-8 w-8 text-blue-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">{patientData.name}</h2>
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Patient ID: {patientData.id}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-4">
            <div className={`px-4 py-2 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-blue-50'}`}>
              <div className="flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-blue-600" />
                <div>
                  <p className="text-xs font-medium">Surgery Date</p>
                  <p className="font-semibold">{formatDate(patientData.surgeryDate)}</p>
                </div>
              </div>
            </div>
            <div className={`px-4 py-2 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-blue-50'}`}>
              <div className="flex items-center">
                <Activity className="h-5 w-5 mr-2 text-blue-600" />
                <div>
                  <p className="text-xs font-medium">Surgery Type</p>
                  <p className="font-semibold">{patientData.surgeryType}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Recovery Progress */}
        <div className={`p-6 rounded-lg shadow-md ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
          <h3 className="text-xl font-bold mb-4 flex items-center">
            <Activity className="h-5 w-5 mr-2 text-blue-600" />
            Recovery Progress
          </h3>
          
          <div className="mb-4">
            <div className="flex justify-between mb-1">
              <span>Healing Progress</span>
              <span>{patientData.healingProgress}%</span>
            </div>
            <div className="w-full bg-gray-300 rounded-full h-2.5">
              <div 
                className="bg-blue-600 h-2.5 rounded-full" 
                style={{ width: `${patientData.healingProgress}%` }}
              ></div>
            </div>
          </div>
          
          <div className="mb-4">
            <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-1`}>Current Stage</p>
            <p className="font-semibold">{patientData.currentStage}</p>
          </div>
          
          <div className="mb-4">
            <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-1`}>Estimated Full Recovery</p>
            <p className="font-semibold">{formatDate(patientData.estimatedRecovery)}</p>
            <p className="text-sm text-blue-600 mt-1">
              {daysRemaining} days remaining
            </p>
          </div>
          
          <div>
            <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-1`}>Next Consultation</p>
            <p className="font-semibold">{formatDate(patientData.nextConsultation)}</p>
          </div>
        </div>
        
        {/* AI Recommendations */}
        <div className={`p-6 rounded-lg shadow-md ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
          <h3 className="text-xl font-bold mb-4 flex items-center">
            <CheckCircle className="h-5 w-5 mr-2 text-blue-600" />
            AI Recommendations
          </h3>
          
          <ul className="space-y-3">
            {patientData.recommendations.map((recommendation, index) => (
              <li key={index} className="flex">
                <ArrowRight className="h-5 w-5 mr-2 text-blue-600 flex-shrink-0 mt-0.5" />
                <span>{recommendation}</span>
              </li>
            ))}
          </ul>
          
          <div className={`mt-6 p-4 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-blue-50'}`}>
            <p className="text-sm">
              <strong>AI Insight:</strong> Based on your recovery pattern, we recommend increasing 
              protein intake and gentle stretching exercises to accelerate tissue regeneration.
            </p>
          </div>
        </div>
        
        {/* Alerts & Reminders */}
        <div className={`p-6 rounded-lg shadow-md ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
          <h3 className="text-xl font-bold mb-4 flex items-center">
            <Bell className="h-5 w-5 mr-2 text-blue-600" />
            Alerts & Reminders
          </h3>
          
          {patientData.alerts.length > 0 ? (
            <ul className="space-y-3 mb-6">
              {patientData.alerts.map((alert, index) => (
                <li key={index} className="flex items-start p-3 bg-red-100 text-red-800 rounded-lg">
                  <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
                  <span>{alert}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mb-6">No critical alerts at this time.</p>
          )}
          
          <div className="space-y-4">
            <div className={`p-3 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-blue-50'}`}>
              <div className="flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-blue-600" />
                <div>
                  <p className="font-medium">Doctor Consultation</p>
                  <p className="text-sm">{formatDate(patientData.nextConsultation)}</p>
                </div>
              </div>
            </div>
            
            <div className={`p-3 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-blue-50'}`}>
              <div className="flex items-center">
                <Activity className="h-5 w-5 mr-2 text-blue-600" />
                <div>
                  <p className="font-medium">Blood Work Due</p>
                  <p className="text-sm">December 1, 2023</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Recovery Timeline */}
      <div className={`mt-8 p-6 rounded-lg shadow-md ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
        <h3 className="text-xl font-bold mb-6 flex items-center">
          <Clock className="h-5 w-5 mr-2 text-blue-600" />
          AI-Predicted Recovery Timeline
        </h3>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-blue-200"></div>
          
          <div className="space-y-8">
            {/* Timeline items */}
            <div className="relative pl-10">
              <div className="absolute left-0 top-1.5 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold">1</span>
              </div>
              <div>
                <h4 className="font-bold">Initial Recovery Phase</h4>
                <p className="text-sm text-blue-600 mb-1">Completed</p>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  The first 2 weeks post-surgery focused on reducing inflammation and 
                  initiating the stem cell activation process.
                </p>
              </div>
            </div>
            
            <div className="relative pl-10">
              <div className="absolute left-0 top-1.5 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold">2</span>
              </div>
              <div>
                <h4 className="font-bold">Cellular Proliferation</h4>
                <p className="text-sm text-blue-600 mb-1">Completed</p>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Weeks 3-6 showed significant increase in stem cell activity and 
                  the beginning of tissue regeneration.
                </p>
              </div>
            </div>
            
            <div className="relative pl-10">
              <div className="absolute left-0 top-1.5 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold">3</span>
              </div>
              <div>
                <h4 className="font-bold">Tissue Regeneration</h4>
                <p className="text-sm text-green-600 mb-1">Current Stage</p>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Weeks 7-12 focus on active tissue rebuilding and functional improvement. 
                  AI predicts 68% completion of this phase.
                </p>
              </div>
            </div>
            
            <div className="relative pl-10">
              <div className="absolute left-0 top-1.5 w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                <span className={`font-bold ${darkMode ? 'text-gray-800' : 'text-gray-600'}`}>4</span>
              </div>
              <div>
                <h4 className="font-bold">Functional Recovery</h4>
                <p className="text-sm text-gray-500 mb-1">Upcoming</p>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Weeks 13-16 will focus on restoring full functionality and strength 
                  to the treated area.
                </p>
              </div>
            </div>
            
            <div className="relative pl-10">
              <div className="absolute left-0 top-1.5 w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                <span className={`font-bold ${darkMode ? 'text-gray-800' : 'text-gray-600'}`}>5</span>
              </div>
              <div>
                <h4 className="font-bold">Complete Recovery</h4>
                <p className="text-sm text-gray-500 mb-1">Upcoming</p>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  By week 20, AI predicts full recovery with optimal tissue integration 
                  and functional restoration.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientDashboard;